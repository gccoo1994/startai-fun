// 网站流量上报脚本（嵌入到每个 HTML 页面底部 </body> 之前）
// 会自动上报：页面 URL、来源、IP停留时长
// 数据存储在 /var/www/analytics/data.json（后台服务部署位置）

const ANALYTICS_API = 'https://startai.fun/analytics-api/collect';

(function() {
  // 节流：同一 IP 同一页面 30 秒内只上报一次
  const key = location.pathname + '_last_send';
  const last = parseInt(sessionStorage.getItem(key) || '0', 10);
  const now = Date.now();
  if (now - last < 30000) return;
  sessionStorage.setItem(key, now.toString());

  // 页面离开时再补一条（计算停留时长）
  let leaveTime = now;

  function send(payload) {
    try {
      navigator.sendBeacon && navigator.sendBeacon(ANALYTICS_API, JSON.stringify(payload));
    } catch {}
  }

  function onLoad() {
    send({ url: location.pathname + location.search, referer: document.referrer });
  }

  function onLeave() {
    const stay = Math.round((Date.now() - leaveTime) / 1000);
    if (stay > 5) {
      send({ url: location.pathname + location.search, stay, type: 'leave' });
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', onLoad);
  } else {
    onLoad();
  }

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') onLeave();
  });

  window.addEventListener('beforeunload', onLeave);
})();
