// analytics-server.js - 轻量级网站监控服务
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');

// ========== 配置 ==========
const PORT = 3001;
const DATA_FILE = '/var/www/analytics/data.json';
const MAX_ONLINE_MS = 5 * 60 * 1000; // 5分钟无活动算离线

// ========== 数据读写（带文件锁） ==========
function readData() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      return { total: 0, records: [], online: {} };
    }
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(raw);
  } catch { return { total: 0, records: [], online: {} }; }
}

function writeData(data) {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
    return true;
  } catch (e) {
    console.error('写入失败:', e.message);
    return false;
  }
}

// ========== 工具函数 ==========
function getIp(req) {
  return (req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || req.socket.remoteAddress || '').split(',')[0].trim();
}

function now() { return Date.now(); }

function getToday() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

function getTodayStats(records) {
  const today = getToday();
  return records.filter(r => r.date === today);
}

function cleanOnline(online) {
  const cutoff = now() - MAX_ONLINE_MS;
  const cleaned = {};
  for (const [ip, info] of Object.entries(online)) {
    if (info.lastAt > cutoff) cleaned[ip] = info;
  }
  return cleaned;
}

// ========== 请求处理 ==========
function sendJson(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(data));
}

function handleCollect(req, res) {
  if (req.method !== 'POST') { sendJson(res, 405, { error: 'Method Not Allowed' }); return; }

  const ip = getIp(req);
  if (!ip) { sendJson(res, 400, { error: 'No IP' }); return; }

  let body = '';
  req.on('data', c => body += c);
  req.on('end', () => {
    let info = {};
    try { info = JSON.parse(body || '{}'); } catch {}

    const data = readData();
    const today = getToday();
    const entry = {
      ip,
      url: info.url || '/',
      referer: info.referer || '',
      userAgent: req.headers['user-agent'] || '',
      firstAt: now(),
      lastAt: now(),
      date: today
    };

    // 更新在线记录
    if (data.online[ip]) {
      data.online[ip].lastAt = now();
      data.online[ip].url = entry.url;
    } else {
      data.online[ip] = { firstAt: now(), lastAt: now(), url: entry.url };
      data.total++; // 只有新IP才计总数
    }

    // 写入 records（今日明细）
    data.records.push(entry);
    // 只保留最近1000条明细
    if (data.records.length > 1000) data.records = data.records.slice(-1000);

    // 清理离线用户
    data.online = cleanOnline(data.online);

    writeData(data);
    sendJson(res, 200, { ok: 1, online: Object.keys(data.online).length });
  });
}

function handleStats(req, res) {
  if (req.method !== 'GET') { sendJson(res, 405, { error: 'Method Not Allowed' }); return; }

  const data = readData();
  const today = getToday();
  data.online = cleanOnline(data.online);

  const todayRecords = data.records.filter(r => r.date === today);
  const todayIps = new Set(todayRecords.map(r => r.ip));
  const todayPages = todayRecords.length;

  // 停留时长（今日所有IP的平均最后活跃距今时间）
  const recentCutoff = now() - 60 * 60 * 1000; // 1小时内
  const recentOnline = Object.values(data.online).filter(o => o.lastAt > recentCutoff);
  const avgStay = recentOnline.length > 0
    ? Math.round(recentOnline.reduce((s, o) => s + (now() - o.firstAt), 0) / recentOnline.length / 1000)
    : 0;

  // 每日统计（最近30天）
  const dailyStats = {};
  const thirtyDaysAgo = new Date(); thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  for (const rec of data.records) {
    if (new Date(rec.date) >= thirtyDaysAgo) {
      if (!dailyStats[rec.date]) dailyStats[rec.date] = { views: 0, ips: new Set() };
      dailyStats[rec.date].views++;
      dailyStats[rec.date].ips.add(rec.ip);
    }
  }

  const daily = Object.entries(dailyStats).map(([date, v]) => ({
    date, views: v.views, visitors: v.ips.size
  })).sort((a,b) => a.date.localeCompare(b.date));

  sendJson(res, 200, {
    total: data.total,
    online: Object.keys(data.online).length,
    onlineList: Object.entries(data.online).map(([ip, o]) => ({
      ip: ip.replace(/::ffff:/, ''),
      stay: Math.round((now() - o.firstAt) / 1000),
      url: o.url,
      lastAt: new Date(o.lastAt).toLocaleTimeString('zh-CN')
    })),
    today: { visitors: todayIps.size, views: todayPages },
    avgStay,
    daily
  });
}

function handleDashboard(req, res) {
  if (req.method !== 'GET') { sendJson(res, 405, { error: 'Method Not Allowed' }); return; }
  const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>StartAI 流量监控</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;background:#0f1117;color:#e6e8eb;min-height:100vh}
header{background:#1a1d27;border-bottom:1px solid #2a2d3a;padding:16px 28px;display:flex;align-items:center;gap:12px}
header h1{font-size:16px;font-weight:700;color:#fff}
header a{font-size:13px;color:#6c8aed;text-decoration:none}
.kpi{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;padding:20px 28px}
.card{background:#1a1d27;border:1px solid #2a2d3a;border-radius:12px;padding:18px 20px}
.card .lb{font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;margin-bottom:6px}
.card .val{font-size:28px;font-weight:800;color:#fff}
.card .val.green{color:#10b981}
.card .val.orange{color:#f59e0b}
.card .val.blue{color:#3b82f6}
.card .sub{font-size:11px;color:#6b7280;margin-top:4px}
.online-wrap{padding:0 28px 16px}
.online-wrap h2{font-size:13px;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px}
.online-list{display:flex;flex-direction:column;gap:6px}
.online-item{background:#1a1d27;border:1px solid #2a2d3a;border-radius:8px;padding:10px 14px;display:flex;align-items:center;gap:12px;font-size:13px}
.online-item .dot{width:8px;height:8px;border-radius:50%;background:#10b981;flex-shrink:0;animation:pulse 2s infinite}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.online-item .ip{color:#818cf8;font-family:monospace;flex-shrink:0}
.online-item .url{color:#9ca3af;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.online-item .stay{color:#6b7280;font-size:12px;flex-shrink:0}
.online-item .time{color:#6b7280;font-size:11px;flex-shrink:0}
.chart-wrap{padding:0 28px 20px}
.chart-wrap h2{font-size:13px;color:#6b7280;text-transform:uppercase;letter-spacing:.06em;margin-bottom:10px}
.chart{background:#1a1d27;border:1px solid #2a2d3a;border-radius:12px;padding:16px;overflow-x:auto}
.bar-row{display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:12px}
.bar-row .date{color:#6b7280;width:80px;flex-shrink:0}
.bar-row .bar-bg{flex:1;height:18px;background:#2a2d3a;border-radius:4px;overflow:hidden}
.bar-row .bar-fill{height:100%;background:linear-gradient(90deg,#10b981,#34d399);border-radius:4px;transition:width .5s}
.bar-row .val{color:#9ca3af;width:60px;text-align:right;flex-shrink:0}
.empty{text-align:center;color:#6b7280;font-size:14px;padding:32px}
footer{padding:16px 28px;border-top:1px solid #2a2d3a;text-align:center;font-size:11px;color:#4b5563}
</style>
</head>
<body>
<header>
  <h1>📊 StartAI 流量监控</h1>
  <a href="https://startai.fun" target="_blank">→ 访问网站</a>
</header>

<div class="kpi">
  <div class="card"><div class="lb">实时在线</div><div class="val green" id="k-online">-</div><div class="sub">当前访问中</div></div>
  <div class="card"><div class="lb">今日访客</div><div class="val blue" id="k-today-visitors">-</div><div class="sub">独立 IP</div></div>
  <div class="card"><div class="lb">今日浏览</div><div class="val blue" id="k-today-views">-</div><div class="sub">页面 PV</div></div>
  <div class="card"><div class="lb">总访问量</div><div class="val" id="k-total">-</div><div class="sub">累计独立访客</div></div>
  <div class="card"><div class="lb">平均停留</div><div class="val orange" id="k-stay">-</div><div class="sub">最近活跃用户</div></div>
</div>

<div class="online-wrap">
  <h2>● 在线用户</h2>
  <div class="online-list" id="online-list">
    <div class="empty">暂无在线用户</div>
  </div>
</div>

<div class="chart-wrap">
  <h2>📈 近30天访问趋势</h2>
  <div class="chart" id="chart"></div>
</div>

<footer>数据每10秒自动刷新 · <a href="https://startai.fun" style="color:#4b5563">startai.fun</a></footer>

<script>
async function load(){
  try {
    const r = await fetch('/analytics-api/stats');
    const d = await r.json();
    
    document.getElementById('k-online').textContent = d.online;
    document.getElementById('k-today-visitors').textContent = d.today ? d.today.visitors : 0;
    document.getElementById('k-today-views').textContent = d.today ? d.today.views : 0;
    document.getElementById('k-total').textContent = d.total;
    document.getElementById('k-stay').textContent = fmtSec(d.avgStay);

    // 在线用户列表
    const ol = document.getElementById('online-list');
    if (d.onlineList && d.onlineList.length > 0) {
      ol.innerHTML = d.onlineList.map(u => \`
        <div class="online-item">
          <div class="dot"></div>
          <div class="ip">\${u.ip}</div>
          <div class="url">\${u.url}</div>
          <div class="stay">停留 \${fmtSec(u.stay)}</div>
          <div class="time">\${u.lastAt}</div>
        </div>\`).join('');
    } else {
      ol.innerHTML = '<div class="empty">暂无在线用户</div>';
    }

    // 图表
    const ch = document.getElementById('chart');
    if (d.daily && d.daily.length > 0) {
      const maxViews = Math.max(...d.daily.map(x => x.views), 1);
      ch.innerHTML = d.daily.map(day => \`
        <div class="bar-row">
          <div class="date">\${day.date}</div>
          <div class="bar-bg"><div class="bar-fill" style="width:\${(day.views/maxViews*100).toFixed(1)}%"></div></div>
          <div class="val">\${day.views} PV / \${day.visitors} UV</div>
        </div>\`).join('');
    } else {
      ch.innerHTML = '<div class="empty">暂无数据</div>';
    }
  } catch(e) {
    console.error(e);
  }
}

function fmtSec(s){
  if (!s || s <= 0) return '0秒';
  if (s < 60) return s + '秒';
  if (s < 3600) return Math.round(s/60) + '分钟';
  return Math.round(s/3600) + '小时';
}

load();
setInterval(load, 10000);
</script>
</body>
</html>`;
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(html);
}

// ========== 路由 ==========
const server = http.createServer((req, res) => {
  const url = req.url.split('?')[0];
  if (url === '/analytics-api/collect') handleCollect(req, res);
  else if (url === '/analytics-api/stats') handleStats(req, res);
  else if (url === '/dashboard' || url === '/' || url === '/index.html') handleDashboard(req, res);
  else {
    res.writeHead(404); res.end('Not Found');
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`✅ 监控服务已启动，端口 ${PORT}`);
  console.log(`📊 Dashboard: http://127.0.0.1:${PORT}/dashboard`);
  console.log(`📡 数据接口: http://127.0.0.1:${PORT}/analytics-api/collect`);
  console.log(`📈 统计接口: http://127.0.0.1:${PORT}/analytics-api/stats`);
});
